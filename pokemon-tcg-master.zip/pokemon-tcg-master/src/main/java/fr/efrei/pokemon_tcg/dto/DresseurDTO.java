package fr.efrei.pokemon_tcg.dto;

public class DresseurDTO {
	private String nom;

	private String prenom;

	public String getNom() {
		return nom;
	}

	public String getPrenom() {
		return prenom;
	}
}

package fr.efrei.pokemon_tcg.constants;

public enum TypePokemon {
	PLANTE, // 0
	FEU, // 1
	EAU // 2
}
